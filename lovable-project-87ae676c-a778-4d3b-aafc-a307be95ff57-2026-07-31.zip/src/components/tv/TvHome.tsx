import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { apps, shelf, sites } from "./data";
import { AppleLogo, GlyphFor, PlayIcon, SearchIcon, SettingsIcon, UserIcon } from "./icons";
import { DetailOverlay } from "./DetailOverlay";

type Pos = { row: number; col: number };

const ROWS = [shelf.length, 6, 6, sites.length];

function useClock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(t);
  }, []);
  if (!now) return { time: "", date: "" };
  const time = now.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  const date = now.toLocaleDateString("es-ES", { weekday: "long", month: "short", day: "numeric" });
  return { time, date: date.charAt(0).toUpperCase() + date.slice(1) };
}

export function TvHome() {
  const [pos, setPos] = useState<Pos>({ row: 0, col: 1 });
  const [open, setOpen] = useState<null | { title: string; subtitle: string; image?: string }>(null);
  const { time, date } = useClock();
  const scrollRefs = useRef<(HTMLDivElement | null)[]>([]);

  const focusedItem = useMemo(() => {
    if (pos.row === 0) return shelf[pos.col]?.title;
    if (pos.row === 1) return apps[pos.col]?.name;
    if (pos.row === 2) return apps[pos.col + 6]?.name;
    return sites[pos.col]?.name;
  }, [pos]);


  const activate = useCallback(() => {
    if (pos.row === 0) {
      const s = shelf[pos.col];
      setOpen({ title: s.title, subtitle: s.subtitle, image: s.image });
    } else if (pos.row === 1 || pos.row === 2) {
      const a = apps[pos.col + (pos.row === 2 ? 6 : 0)];
      setOpen({ title: a.name, subtitle: "Aplicación" });
    } else {
      setOpen({ title: sites[pos.col].name, subtitle: "Página web favorita" });
    }
  }, [pos]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (open) {
        if (e.key === "Escape" || e.key === "Backspace") setOpen(null);
        return;
      }
      const k = e.key;
      if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Enter", " "].includes(k)) return;
      e.preventDefault();
      if (k === "Enter" || k === " ") return activate();
      setPos((p) => {
        if (k === "ArrowLeft") return { ...p, col: Math.max(0, p.col - 1) };
        if (k === "ArrowRight") return { ...p, col: Math.min(ROWS[p.row] - 1, p.col + 1) };
        const row = k === "ArrowUp" ? Math.max(0, p.row - 1) : Math.min(ROWS.length - 1, p.row + 1);
        return { row, col: Math.min(p.col, ROWS[row] - 1) };
      });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activate, open]);

  useEffect(() => {
    const container = scrollRefs.current[pos.row];
    const el = container?.querySelector<HTMLElement>(`[data-col="${pos.col}"]`);
    el?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [pos]);

  const focused = (row: number, col: number) => pos.row === row && pos.col === col;

  return (
    <div className="tv-surface relative min-h-screen w-full overflow-hidden pb-16">
      {/* status bar */}
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-6 pt-5 sm:grid-cols-3 sm:px-10">
        <div className="flex min-w-0 items-center gap-3">
          <AppleLogo className="h-6 w-6 shrink-0 text-foreground/80" />
          <div className="min-w-0 leading-tight">
            <p className="truncate text-sm font-semibold text-foreground/90">{time}</p>
            <p className="truncate text-xs text-foreground/50">{date}</p>
          </div>
          <span className="tv-glass ml-1 hidden h-8 w-8 shrink-0 place-items-center rounded-full sm:grid">
            <UserIcon className="h-4 w-4 text-foreground/70" />
          </span>
        </div>
        <h1 className="hidden text-center text-sm font-semibold tracking-[0.22em] text-foreground/80 sm:block">
          INICIO
        </h1>
        <div className="flex items-center justify-end gap-3">
          <div className="tv-glass flex h-9 items-center gap-2 rounded-full px-4">
            <SearchIcon className="h-4 w-4 shrink-0 text-foreground/50" />
            <span className="text-sm text-foreground/50">Buscar</span>
          </div>
          <span className="tv-glass grid h-9 w-9 shrink-0 place-items-center rounded-full">
            <SettingsIcon className="h-4 w-4 text-foreground/70" />
          </span>
        </div>
      </header>

      {/* top shelf */}
      <section className="mt-6">
        <h2 className="px-6 text-lg font-semibold text-foreground/85 sm:px-10">Top Shelf</h2>
        <div
          ref={(el) => {
            scrollRefs.current[0] = el;
          }}
          className="hide-scrollbar mt-3 flex snap-x gap-5 overflow-x-auto px-6 py-6 sm:px-10"
        >
          {shelf.map((s, i) => (
            <button
              key={s.id}
              data-col={i}
              onMouseEnter={() => setPos({ row: 0, col: i })}
              onClick={() => setOpen({ title: s.title, subtitle: s.subtitle, image: s.image })}
              className={`focusable tile-base relative h-40 w-[19rem] shrink-0 snap-center text-left sm:h-48 sm:w-[26rem] ${
                focused(0, i) ? "is-focused" : ""
              }`}
            >
              <img
                src={s.image}
                alt={s.title}
                width={1280}
                height={720}
                loading={i < 2 ? undefined : "lazy"}
                className="absolute inset-0 h-full w-full object-cover"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              <span className="absolute right-4 top-4">
                <GlyphFor badge={s.badge} />
              </span>
              {focused(0, i) && (
                <span className="tv-glass absolute bottom-4 left-4 grid h-10 w-10 place-items-center rounded-full">
                  <PlayIcon className="h-4 w-4 text-foreground" />
                </span>
              )}
              <span className="absolute bottom-4 left-4 right-4 flex flex-col items-start pl-14">
                <span className="truncate text-base font-semibold text-white">{s.title}</span>
                <span className="truncate text-xs text-white/70">{s.subtitle}</span>
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* app grid */}
      {[0, 1].map((r) => (
        <div
          key={r}
          ref={(el) => {
            scrollRefs.current[r + 1] = el;
          }}
          className="hide-scrollbar flex gap-5 overflow-x-auto px-6 py-4 sm:px-10"
        >
          {apps.slice(r * 6, r * 6 + 6).map((a, i) => (
            <button
              key={a.id}
              data-col={i}
              onMouseEnter={() => setPos({ row: r + 1, col: i })}
              onClick={() => setOpen({ title: a.name, subtitle: "Aplicación" })}
              className={`focusable tile-base ${a.className} h-24 w-40 shrink-0 sm:h-28 sm:w-48 ${
                focused(r + 1, i) ? "is-focused" : ""
              }`}
              aria-label={a.name}
            >
              {a.kind === "wordmark" ? (
                <span
                  className={`px-3 text-center font-bold tracking-tight ${
                    a.id === "netflix" ? "text-xl tracking-[0.08em]" : "text-lg"
                  }`}
                >
                  {a.label}
                </span>
              ) : (
                <GlyphFor badge={a.id} className="h-10 w-auto" />
              )}
            </button>
          ))}
        </div>
      ))}

      {/* favorite sites */}
      <section className="mt-4">
        <h2 className="px-6 text-lg font-semibold text-foreground/85 sm:px-10">Páginas Web Favoritas</h2>
        <div
          ref={(el) => {
            scrollRefs.current[3] = el;
          }}
          className="hide-scrollbar mt-3 flex gap-4 overflow-x-auto px-6 py-5 sm:px-10"
        >
          {sites.map((s, i) => (
            <button
              key={s.id}
              data-col={i}
              onMouseEnter={() => setPos({ row: 3, col: i })}
              onClick={() => setOpen({ title: s.name, subtitle: "Página web favorita" })}
              className={`focusable tile-base ${s.className} h-20 w-24 shrink-0 text-xl font-bold sm:h-[5.5rem] sm:w-28 ${
                focused(3, i) ? "is-focused" : ""
              }`}
              aria-label={s.name}
            >
              {s.short}
            </button>
          ))}
        </div>
      </section>

      <footer className="pointer-events-none fixed bottom-4 left-1/2 -translate-x-1/2">
        <div className="tv-glass rounded-full px-4 py-2 text-xs text-foreground/60">
          Usa ← ↑ ↓ → para navegar · Enter para abrir · Esc para volver ·{" "}
          <span className="font-semibold text-foreground/80">{focusedItem}</span>
        </div>
      </footer>

      {open && <DetailOverlay item={open} onClose={() => setOpen(null)} />}
    </div>
  );
}
