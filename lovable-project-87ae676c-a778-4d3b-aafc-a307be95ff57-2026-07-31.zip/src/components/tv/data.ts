import shelf1 from "@/assets/shelf-1.jpg";
import shelf2 from "@/assets/shelf-2.jpg";
import shelf3 from "@/assets/shelf-3.jpg";
import shelf4 from "@/assets/shelf-4.jpg";

export type ShelfItem = {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  image: string;
};

export const shelf: ShelfItem[] = [
  { id: "s3", title: "Sombras", subtitle: "Serie · Temporada 2", badge: "apple", image: shelf3 },
  { id: "s1", title: "El Entrenador", subtitle: "Apple TV+", badge: "apple", image: shelf1 },
  { id: "s2", title: "Niebla Roja", subtitle: "Ver ahora", badge: "netflix", image: shelf2 },
  { id: "s4", title: "Ciudad Dorada", subtitle: "YouTube", badge: "youtube", image: shelf4 },
];

export type AppTile = {
  id: string;
  name: string;
  kind: "wordmark" | "icon";
  className: string;
  label?: string;
};

export const apps: AppTile[] = [
  { id: "appletv", name: "Apple TV+", kind: "icon", className: "tile-appletv" },
  { id: "music", name: "Música", kind: "icon", className: "tile-music" },
  { id: "arcade", name: "Arcade", kind: "icon", className: "tile-arcade" },
  { id: "safari", name: "Safari", kind: "icon", className: "tile-safari" },
  { id: "netflix", name: "Netflix", kind: "wordmark", className: "tile-netflix", label: "NETFLIX" },
  { id: "youtube", name: "YouTube", kind: "icon", className: "tile-youtube" },
  { id: "disney", name: "Disney+", kind: "wordmark", className: "tile-disney", label: "Disney+" },
  { id: "prime", name: "Prime Video", kind: "wordmark", className: "tile-prime", label: "prime video" },
  { id: "hbo", name: "HBO Max", kind: "wordmark", className: "tile-hbo", label: "HBOMAX" },
  { id: "spotify", name: "Spotify", kind: "icon", className: "tile-spotify" },
  { id: "twitch", name: "Twitch", kind: "wordmark", className: "tile-twitch", label: "twitch" },
  { id: "appstore", name: "App Store", kind: "icon", className: "tile-appstore" },
];

export type WebSite = { id: string; name: string; short: string; className: string };

export const sites: WebSite[] = [
  { id: "google", name: "Google", short: "G", className: "site-google" },
  { id: "wiki", name: "Wikipedia", short: "W", className: "site-wiki" },
  { id: "elpais", name: "El País", short: "EP", className: "site-elpais" },
  { id: "bbc", name: "BBC News", short: "BBC", className: "site-bbc" },
  { id: "web", name: "Web", short: "◍", className: "site-web" },
  { id: "quora", name: "Quora", short: "Q", className: "site-quora" },
  { id: "espn", name: "ESPN", short: "E", className: "site-espn" },
  { id: "reddit", name: "Reddit", short: "R", className: "site-reddit" },
  { id: "search", name: "Buscar", short: "Q", className: "site-search" },
];
